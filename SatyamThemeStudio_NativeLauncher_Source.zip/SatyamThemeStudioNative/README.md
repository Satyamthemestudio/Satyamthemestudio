# Satyam Theme Studio — Native Android Launcher

A native Kotlin Android launcher starter project tailored to the Vivo Y400 5G. It is a real launcher implementation (not a web page): it registers as a HOME app, enumerates launchable apps, opens apps, filters the app list, supports long-press favourites, lets the user choose and apply a home-screen wallpaper, and persists basic launcher preferences.

## Current functionality
- Registers as an Android Home app (`MAIN` + `HOME` + `DEFAULT`) and as a normal app-drawer launch target.
- Lists installed apps that expose a launcher activity; tap an app icon to launch it.
- Search/filter installed apps.
- Long-press an app to toggle a saved favourite marker.
- Change grid columns (3/4/5), icon size, and app-label visibility.
- Choose a photo from Gallery and apply it as the system home wallpaper using `WallpaperManager`.
- Five built-in free colour themes; persists theme and launcher preferences.
- Dark navy / champagne-gold styling.

## Build an APK
This source project has not been compiled in this environment because Android SDK / Gradle build tools are not installed here. To build it:
1. Install Android Studio on a Windows, macOS, or Linux computer.
2. Open this project folder (`SatyamThemeStudioNative`) in Android Studio.
3. Install Android SDK Platform 35 and a compatible Android Gradle Plugin toolchain when prompted.
4. Let Gradle sync complete.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Transfer `app/build/outputs/apk/debug/app-debug.apk` to the Vivo Y400 5G and install it. Allow installation from that file manager if Android asks.
7. Press Home and choose **Satyam Theme Studio**; select **Always** to make it the default launcher.

## Vivo setup notes
If Vivo does not show the default-home chooser automatically, open **Settings → Apps → Default apps → Home app** and select Satyam Theme Studio. Menu names can vary by Funtouch OS release.

## Important limitations / next development work
- This is a functional starter launcher, not a full replacement for every Vivo system component.
- Android launchers cannot universally replace third-party app icons inside other apps, the status bar, notification shade, lock screen, or system Settings. Those remain controlled by Android/Vivo unless a supported theme engine or separate permissioned component is used.
- The current theme selection changes the launcher accent and saved preference; advanced per-app icon-pack loading, drag-and-drop placement, widget hosting, folders, notification dots, backup/restore UI, and a curated bundled wallpaper gallery are not implemented yet.
- No analytics, accounts, ads, or network permissions are included.
