package com.satyam.themestudio

import android.app.WallpaperManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.view.setPadding
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("studio", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    private var allApps: List<ResolveInfo> = emptyList()
    private var selectedTheme = "Midnight Gold"
    private var columns = 4
    private var iconDp = 54
    private var labelsVisible = true
    private var accent = GOLD
    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) applyWallpaper(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedTheme = prefs.getString("theme", "Midnight Gold") ?: "Midnight Gold"
        columns = prefs.getInt("columns", 4)
        iconDp = prefs.getInt("icon", 54)
        labelsVisible = prefs.getBoolean("labels", true)
        accent = prefs.getInt("accent", GOLD)
        buildUi()
        loadApps()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(16)); fitsSystemWindows = true }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "✦"; textSize = 30f; setTextColor(GOLD); gravity = Gravity.CENTER; background = bg(0xFF182A42.toInt(), 16); layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)) }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleBox.addView(text("SATYAM THEME STUDIO", 18f, WHITE, true))
        titleBox.addView(text("Your phone. Your style.", 12f, MUTED, false))
        header.addView(brand); header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = button("⚙", GOLD) { showSettings() }; header.addView(settings)
        root.addView(header)
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xFF14243A.toInt(), 22); setPadding(dp(16)); layoutParams = margin(top = 16, bottom = 12) }
        hero.addView(text("Good ${if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 12) "morning" else "evening"}", 14f, MUTED, false))
        hero.addView(text("Make it yours.", 27f, WHITE, true))
        hero.addView(text("A clean, iOS-inspired home for your Vivo.", 13f, MUTED, false))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(button("Choose wallpaper", GOLD) { wallpaperPicker.launch("image/*") }, LinearLayout.LayoutParams(0, dp(44), 1f))
        actions.addView(button("Themes", GOLD) { showThemes() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
        hero.addView(actions, margin(top = 14)); root.addView(hero)
        search = EditText(this).apply {
            hint = "Search your apps"; setHintTextColor(MUTED); setTextColor(WHITE); textSize = 15f
            singleLine = true; setPadding(dp(16), 0, dp(16), 0); background = bg(0xFF14243A.toInt(), 16)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(12) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Your apps", 19f, WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("A–Z", GOLD) { allApps = allApps.sortedBy { it.loadLabel(packageManager).toString().lowercase() }; renderApps(search.text.toString()) })
        root.addView(row)
        status = text("Loading apps…", 12f, MUTED, false); root.addView(status, margin(top = 8, bottom = 6))
        val scroll = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        appGrid = GridLayout(this).apply { columnCount = columns; alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false }
        scroll.addView(appGrid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = bg(0xFF14243A.toInt(), 18); setPadding(dp(8)) }
        footer.addView(button("Home", GOLD) { search.setText(""); search.clearFocus() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        footer.addView(button("Themes", GOLD) { showThemes() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        footer.addView(button("Wallpaper", GOLD) { wallpaperPicker.launch("image/*") }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(footer, margin(top = 10))
        setContentView(root)
    }

    private fun loadApps() {
        thread {
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val result = packageManager.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
            runOnUiThread { allApps = result; renderApps("") }
        }
    }

    private fun renderApps(query: String) {
        if (!::appGrid.isInitialized) return
        appGrid.removeAllViews(); appGrid.columnCount = columns
        val filtered = allApps.filter { it.loadLabel(packageManager).toString().contains(query, true) }
        status.text = "${filtered.size} apps · Long-press an app to add/remove favourite"
        val favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        filtered.forEach { info ->
            val pkg = info.activityInfo.packageName
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4)); background = rippleBg() }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER; layoutParams = LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)) }
            val label = TextView(this).apply { text = info.loadLabel(packageManager).toString() + if (favorites.contains(pkg)) " ★" else ""; setTextColor(if (favorites.contains(pkg)) GOLD else WHITE); textSize = 11f; gravity = Gravity.CENTER; maxLines = 2; visibility = if (labelsVisible) View.VISIBLE else View.GONE; setPadding(0, dp(5), 0, 0) }
            cell.addView(icon); cell.addView(label)
            cell.setOnClickListener { launchApp(info) }
            cell.setOnLongClickListener { toggleFavorite(pkg); renderApps(search.text.toString()); true }
            val item = GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(4), dp(2), dp(4)) }
            appGrid.addView(cell, item)
        }
        if (filtered.isEmpty()) { val empty = text("No matching apps", 14f, MUTED, false); appGrid.addView(empty) }
    }

    private fun launchApp(info: ResolveInfo) {
        val intent = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
        if (intent != null) try { startActivity(intent) } catch (_: Exception) { toast("Unable to open this app") }
    }

    private fun toggleFavorite(pkg: String) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (!set.add(pkg)) set.remove(pkg)
        prefs.edit().putStringSet("favorites", set).apply()
        toast(if (set.contains(pkg)) "Added to favourites" else "Removed from favourites")
    }

    private fun showThemes() {
        val names = arrayOf("Midnight Gold", "iOS Glass", "Ocean Blue", "Emerald Night", "Silver Minimal")
        android.app.AlertDialog.Builder(this).setTitle("Choose a free theme").setSingleChoiceItems(names, names.indexOf(selectedTheme).coerceAtLeast(0)) { dialog, which ->
            selectedTheme = names[which]
            accent = when (selectedTheme) { "Ocean Blue" -> 0xFF72B7FF.toInt(); "Emerald Night" -> 0xFF64D6A5.toInt(); "Silver Minimal" -> 0xFFD6DCE7.toInt(); else -> GOLD }
            prefs.edit().putString("theme", selectedTheme).putInt("accent", accent).apply()
            toast("$selectedTheme applied to launcher"); dialog.dismiss(); rebuildColors()
        }.setNegativeButton("Close", null).show()
    }

    private fun showSettings() {
        val choices = arrayOf("Change grid columns (3 / 4 / 5)", "Change icon size", "Toggle app labels", "Set as default Home app", "Choose wallpaper", "Free themes")
        android.app.AlertDialog.Builder(this).setTitle("Launcher settings").setItems(choices) { _, which -> when (which) {
            0 -> android.app.AlertDialog.Builder(this).setTitle("Grid columns").setItems(arrayOf("3", "4", "5")) { _, n -> columns = n + 3; prefs.edit().putInt("columns", columns).apply(); renderApps(search.text.toString()) }.show()
            1 -> android.app.AlertDialog.Builder(this).setTitle("Icon size").setItems(arrayOf("Small", "Medium", "Large")) { _, n -> iconDp = listOf(46, 54, 64)[n]; prefs.edit().putInt("icon", iconDp).apply(); renderApps(search.text.toString()) }.show()
            2 -> { labelsVisible = !labelsVisible; prefs.edit().putBoolean("labels", labelsVisible).apply(); renderApps(search.text.toString()) }
            3 -> requestDefaultHome()
            4 -> wallpaperPicker.launch("image/*")
            5 -> showThemes()
        } }.setNegativeButton("Close", null).show()
    }

    private fun requestDefaultHome() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 200)
            else toast("Open Settings → Apps → Default apps → Home app and choose Satyam Theme Studio")
        } else {
            try { startActivity(Intent("android.settings.HOME_SETTINGS")) } catch (_: Exception) { toast("Choose Satyam Theme Studio from your Home app settings") }
        }
    }

    private fun applyWallpaper(uri: Uri) {
        try {
            val stream = contentResolver.openInputStream(uri) ?: throw Exception("Cannot read image")
            stream.use { WallpaperManager.getInstance(this).setStream(it, null, true, WallpaperManager.FLAG_SYSTEM) }
            toast("Home wallpaper updated")
        } catch (e: Exception) { toast("Wallpaper could not be applied: ${e.localizedMessage ?: "permission error"}") }
    }

    private fun rebuildColors() { root.setBackgroundColor(BG); status.setTextColor(MUTED); renderApps(search.text.toString()) }
    private fun button(label: String, color: Int, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(if (color == GOLD) 0xFF172033.toInt() else WHITE)
        background = bg(color, 13); setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { action() }
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun bg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun rippleBg(): android.graphics.drawable.Drawable = android.util.TypedValue().let { bg(0x00112233, 14) }
    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private const val BG = 0xFF07111F.toInt()
        private const val WHITE = 0xFFF7F8FB.toInt()
        private const val MUTED = 0xFFAAB6C6.toInt()
        private const val GOLD = 0xFFE8BD69.toInt()
    }
}
